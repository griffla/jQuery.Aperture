$(function() {
	
	$('#aperture')
	.aperture({
		columns: '4',
		duration : 700,
		direction : 'cw',
	});
	
});